package splat.lexer;

import java.util.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;


/**
 * The Lexer class is responsible for tokenizing source code files.
 */
public class Lexer {

	private File sourceFile;

	/**
	 * Constructs a Lexer object with the given source file.
	 *
	 * @param progFile The source file to be tokenized.
	 */
	public Lexer(File progFile) {
		this.sourceFile = progFile;
	}

	/**
	 * Tokenizes the source code and returns a list of tokens.
	 *
	 * @return A list of Token objects representing the tokens in the source code.
	 * @throws LexException If there is an issue during the lexical analysis.
	 * @throws IOException  If there is an issue reading the source file.
	 */
	public List<Token> tokenize() throws LexException, IOException {
		List<Token> tokns = new LinkedList();

		try (BufferedReader handler = new BufferedReader(new FileReader(sourceFile))) {
			int LinePosition = 1;
			String
					RowNumber;

			while ((RowNumber = handler.readLine()) != null) {
				controlLine(RowNumber, LinePosition, tokns);
				LinePosition++;
			}
		}

		return tokns;
	}


	/**
	 * Processes a RowNumber of source code, extracting tokens and updating the token list.
	 *
	 * @param RowNumber   The RowNumber of source code to be processed.
	 * @param LinePosition    The current LinePosition number.
	 * @param tokens The list of tokens to be updated.
	 * @throws LexException If there is an issue during the lexical analysis.
	 */
	private void controlLine(String RowNumber, int LinePosition, List<Token> tokens) throws LexException {
		StringTokenizer tokenizer = new StringTokenizer(RowNumber, " \t");
		int col = 1;
		Stack<Character> qte = new Stack<>();
		StringBuilder oper = new StringBuilder();
		StringBuilder Lexeme = new StringBuilder();

		List<Boolean> allChar = crAllChaL();

		List<Character> Executives = Arrays.asList('>', '<', '/', '*', '-', '+', '%');
		List<String> compOperators = Arrays.asList(">=", "<=", "==", ":=", "and", "or");
		List<Character> symChar = Arrays.asList('.', ',', ';', ':', '(', ')', '{', '}');

		do {
			String tokenValue = tokenizer.hasMoreTokens() ? tokenizer.nextToken() : null;
			boolean allexp = true;

			if (tokenValue != null) {
				for (int i = 0; i < tokenValue.length(); i++) {
					Lexeme.append(allexp && !qte.isEmpty() ? " " : "");

					if (tokenValue.charAt(i) == ' ' || tokenValue.charAt(i) == '\t') continue;

					if (qte.isEmpty() && symChar.contains(tokenValue.charAt(i))) {
						sequence(oper, Lexeme, tokens, qte, LinePosition, col);
						tokens.add(new Token(String.valueOf(tokenValue.charAt(i)), LinePosition, col));
					} else if (Arrays.asList('"', '\'').contains(tokenValue.charAt(i)) && qte.isEmpty()) {
						controlQuote(tokenValue.charAt(i), qte, oper, Lexeme, tokens, LinePosition, col);
					} else if (Arrays.asList('"', '\'').contains(tokenValue.charAt(i))) {
						closeQuote(tokenValue.charAt(i), qte, oper, Lexeme, tokens, LinePosition, col);
					} else if ((Executives.contains(tokenValue.charAt(i)) || tokenValue.charAt(i) == '=') && qte.isEmpty()) {
						handlOpe(tokenValue.charAt(i), compOperators, oper, Lexeme, tokens, qte, LinePosition, col);
					} else if (!qte.isEmpty()) {
						Lexeme.append(tokenValue.charAt(i));
					} else if (allChar.get(tokenValue.charAt(i))) {
						Lexeme.append(tokenValue.charAt(i));
					} else if (!allChar.get(tokenValue.charAt(i)) && qte.isEmpty()) {
						throw new LexException("\n" + "Detected a disallowed character in the input" + tokenValue.charAt(i), LinePosition, col);
					}

					allexp = false;
					col++;
				}

				sequence(oper, Lexeme, tokens, qte, LinePosition, col);
			}

		} while (tokenizer.hasMoreTokens());

		if (!qte.isEmpty()) {
			throw new LexException("\n" + "Quote is left open", LinePosition, col);
		}
	}


	/**
	 * Handles the opening cquote, pushing it onto the stack.
	 *
	 * @param quoteChar The opening cquote character.
	 * @param cquote     The stack of cquote characters.
	 * @param oper  The current oper being constructed.
	 * @param word      The current word being constructed.
	 * @param tokens    The list of tokens to be updated.
	 * @param LinePosition       The current LinePosition number.
	 * @param ColumnIndex    The current ColumnIndex number.
	 * @throws LexException If there is an issue during the lexical analysis.
	 */
	private void controlQuote(char quoteChar, Stack<Character> cquote, StringBuilder oper, StringBuilder word,
							  List<Token> tokens, int LinePosition, int ColumnIndex) throws LexException {
		cquote.push(quoteChar);
	}

	/**
	 * Handles the closing QuotationMark, popping the stack and adding the token.
	 *
	 * @param quoteChar The closing QuotationMark character.
	 * @param QuotationMark     The stack of QuotationMark characters.
	 * @param operator  The current operator being constructed.
	 * @param Lexeme      The current Lexeme being constructed.
	 * @param tokens    The list of tokens to be updated.
	 * @param LinePosition       The current LinePosition number.
	 * @param ColumnIndex    The current ColumnIndex number.
	 * @throws LexException If there is an issue during the lexical analysis.
	 */
	private void closeQuote(char quoteChar, Stack<Character> QuotationMark, StringBuilder operator, StringBuilder Lexeme,
							List<Token> tokens, int LinePosition, int ColumnIndex) throws LexException {
		switch (quoteChar) {
			case '"':
			case '\'':
				if (QuotationMark.isEmpty()) {
					throw new LexException("No corresponding opening QuotationMark for the closing QuotationMark", LinePosition, ColumnIndex);
				} else if (quoteChar == '"' && QuotationMark.peek() != '"') {
					throw new LexException("No corresponding opening QuotationMark for the closing QuotationMark", LinePosition, ColumnIndex);
				} else if (quoteChar == '\'' && QuotationMark.peek() != '\'') {
					throw new LexException("No corresponding opening QuotationMark for the closing QuotationMark", LinePosition, ColumnIndex);
				} else {
					handleOpEq(operator, Lexeme, tokens, QuotationMark, LinePosition, ColumnIndex);
					tokens.add(new Token(QuotationMark.peek() + Lexeme.toString() + QuotationMark.peek(), LinePosition, ColumnIndex - Lexeme.length() + 1));
					Lexeme.setLength(0);
					QuotationMark.pop();
				}
				break;
			default:

				break;
		}
	}


	/**
	 * Handles operators, adding them to the token list.
	 *
	 * @param currentChar      The current character being processed.
	 * @param complOper The list of complex operators.
	 * @param oper         The current oper being constructed.
	 * @param Lexeme             The current Lexeme being constructed.
	 * @param tokens           The list of tokens to be updated.
	 * @param qte            The stack of quote characters.
	 * @param LinePosition              The current LinePosition number.
	 * @param ColumnIndex           The current ColumnIndex number.
	 * @throws LexException If there is an issue during the lexical analysis.
	 */
	private void handlOpe(char currentChar, List<String> complOper, StringBuilder oper,
						  StringBuilder Lexeme, List<Token> tokens, Stack<Character> qte, int LinePosition, int ColumnIndex) throws LexException {
		if (complOper.contains(oper.toString())) {
			tokens.add(new Token(oper.toString(), LinePosition, ColumnIndex - oper.length() + 1));
			oper.setLength(0);
		}
		if (Lexeme.length() > 0) {
			sequence(oper,Lexeme, tokens, qte, LinePosition, ColumnIndex);
		}
		oper.append(currentChar);
	}

	/**
	 * Handles operators and equals sign, adding them to the token list.
	 *
	 * @param oper The current oper being constructed.
	 * @param Lexeme     The current Lexeme being constructed.
	 * @param tokens   The list of tokens to be updated.
	 * @param QuotationMark    The stack of QuotationMark characters.
	 * @param LinePosition      The current LinePosition number.
	 * @param column   The current column number.
	 * @throws LexException If there is an issue during the lexical analysis.
	 */
	private void handleOpEq(StringBuilder oper, StringBuilder Lexeme, List<Token> tokens,
							Stack<Character> QuotationMark, int LinePosition, int column) throws LexException {
		if (oper.length() > 0) {
			if (oper.toString().equals("=") && !tokens.getLast().getValue().equals(":")) {
				throw new LexException("\n" + "Inappropriate utilization of the equal sign", LinePosition, column);
			}
			tokens.add(new Token(oper.toString(), LinePosition, column - oper.length() + 1));
			oper.setLength(0);
		}
		if (Lexeme.length() > 0 && QuotationMark.isEmpty()) {
			tokens.add(new Token(Lexeme.toString(), LinePosition, column - Lexeme.length() + 1));
			Lexeme.setLength(0);
		}
	}

	/**
	 * Adds the current Lexeme or oper to the token list.
	 *
	 * @param oper The current oper being constructed.
	 * @param Lexeme     The current Lexeme being constructed.
	 * @param tokens   The list of tokens to be updated.
	 * @param qte    The stack of qte characters.
	 * @param LinePosition      The current LinePosition number.
	 * @param ColumnIndex   The current ColumnIndex number.
	 * @throws LexException If there is an issue during the lexical analysis.
	 */
	private void sequence(StringBuilder oper, StringBuilder Lexeme, List<Token> tokens,
						  Stack<Character> qte, int LinePosition, int ColumnIndex) throws LexException {
		handleOpEq(oper, Lexeme, tokens, qte, LinePosition, ColumnIndex);
	}

	/**
	 * Creates a list of allowed characters for lexical analysis.
	 *
	 * @return A list of Boolean values indicating whether each ASCII character is allowed.
	 */
	private List<Boolean> crAllChaL() {
		List<Boolean> allwdChar = new ArrayList<>(256);

		for (int i = 0; i <= 255; i++) {
			if (i == 34 || (i >= 39 && i <= 62) || (i >= 65 && i <= 90) || i == 95 || (i >= 97 && i <= 123) || i == 125) {
				allwdChar.add(i, true);
			} else {
				allwdChar.add(i, false);
			}
		}
		return allwdChar;
	}
}
