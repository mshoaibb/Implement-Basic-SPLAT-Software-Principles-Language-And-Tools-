package splat.semanticanalyzer;

import java.util.*;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import splat.parser.elements.extraelements.Type;
import splat.parser.elements.Declaration;
import splat.parser.elements.FunctionDecl;
import splat.parser.elements.ProgramAST;
import splat.parser.elements.Statement;
import splat.parser.elements.VariableDecl;

public class SemanticAnalyzer {

	private ProgramAST progAST;

	// Map to store function declarations with their labels
	private Map<String, FunctionDecl> funcMap = new HashMap<>(); // Declaration
	// Map to store program variables with their types
	private Map<String, Type> progVarMap = new HashMap<>(); // Type

	public SemanticAnalyzer(ProgramAST progAST) {
		this.progAST = progAST;
	}

	public void analyze() throws SemanticAnalysisException {

		// Checks to make sure we don't use the same labels more than once
		// for our program functions and variables
		checkNoDuplicateProgLabels(); // Checking declaration of function on duplicates

		// This sets the maps that will be needed later when we need to
		// typecheck variable references and function calls in the
		// program body
		setProgVarAndFuncMaps();

		// Perform semantic analysis on the functions
		for (FunctionDecl funcDecl : funcMap.values()) {
			analyzeFuncDecl(funcDecl);
		}

		// Perform semantic analysis on the program body
		for (Statement stmt : progAST.getStmts()) {
			stmt.analyze(funcMap, progVarMap);
		}
	}

	// Analyze a function declaration
	private void analyzeFuncDecl(FunctionDecl funcDecl) throws SemanticAnalysisException {

		// Checks to make sure we don't use the same labels more than once
		// among our function parameters, local variables, and function names
		checkNoDuplicateFuncLabels(funcDecl);

		// Get the types of the parameters and local variables
		Map<String, Type> varAndParamMap = getVarAndParamMap(funcDecl);

		// Perform semantic analysis on the function body
		for (Statement stmt : funcDecl.getState()) {
			stmt.analyze(funcMap, varAndParamMap);
		}

		// Retrieve the return type of the function.
		Type ResultType = varAndParamMap.get("0return");

		// Check if the return type is not void.
		boolean NonVoidResult = ResultType != Type.Void;

		// Check if there is no variable representing the actual return value.
		boolean AbsentReturn = !varAndParamMap.containsKey("0ActualReturn");

		// Combine the conditions and throw an exception if necessary.
		if (NonVoidResult && AbsentReturn) {
			throw new SemanticAnalysisException("\n" +"The function is missing a required return statement", funcDecl);
		}
	}

	// Create a map of variable and parameter labels to their data types
	private Map<String, Type> getVarAndParamMap(FunctionDecl funcDecl) {

		// FIXME: Somewhat similar to setProgVarAndFuncMaps()
		Map<String, Type> ArgVarAssociationMapping = new HashMap<>();

		// Storing info about parameters of a function
		funcDecl.retrieveParam().forEach(decl -> ArgVarAssociationMapping.put(decl.ObtainSymbolName(), decl.fetchType()));

		// Storing info about variables of a function
		funcDecl.fetchelement().forEach(decl -> ArgVarAssociationMapping.put(decl.ObtainSymbolName(), decl.fetchType()));

		// Storing info about return of a function
		ArgVarAssociationMapping.put("0return", funcDecl.fetchType());

		return ArgVarAssociationMapping;
	}

	// Check for duplicate labels in function parameters, local variables, and clashes with function names
	private void checkNoDuplicateFuncLabels(FunctionDecl funcDecl) throws SemanticAnalysisException {

		// FIXME: Similar to checkNoDuplicateProgLabels()
		// Checking for Replica/duplicate  parameters
		Set<String> Replica = new HashSet<String>();
		List<VariableDecl> paramList = funcDecl.retrieveParam();
		int size = paramList.size();

		for (int i = 0; i < size; i++) {
			VariableDecl Declare = paramList.get(i);
			String SymbolName = Declare.ObtainSymbolName();

			if (Replica.contains(SymbolName)) {
				throw new SemanticAnalysisException("\n" + "Duplicate SymbolName is not allowed within the parameters of a function" + SymbolName
						+ " ", Declare);
			} else {
				Replica.add(SymbolName);
			}
		}


		// Checking for Replica/duplicate local placeholders
		List<String> dLabels = funcDecl.fetchelement()
				.stream()
				.map(VariableDecl::ObtainSymbolName)
				.filter(label -> !Replica.add(label))
				.collect(Collectors.toList());

		if (!dLabels.isEmpty()) {
			String dLabel = dLabels.get(0);
			throw new SemanticAnalysisException("Duplicate label is not allowed within the parameters of a function" + dLabel + " ", funcDecl);
		}

		// Checking if parameters clash with functions name
		Iterator<VariableDecl> iterator = funcDecl.retrieveParam().iterator();

		while (iterator.hasNext()) {
			VariableDecl decl = iterator.next();
			String label = decl.ObtainSymbolName();

			if (funcMap.containsKey(label)) {
				throw new SemanticAnalysisException("The Tag with the identical name as the program function is not permitted within the parameters of a function"
						+ label + " ", decl);
			}
		}

		// Checking if local placeholders/variables clash with functions name
		List<VariableDecl> placeholders = funcDecl.fetchelement();
		int s = placeholders.size();

		for (int i = 0; i < s; i++) {
			VariableDecl decl = placeholders.get(i);
			String Tag = decl.ObtainSymbolName();

			if (funcMap.containsKey(Tag)) {
				throw new SemanticAnalysisException("The Tag with the identical name as the program function is not permitted within the local placeholders of a function"
						+ Tag + " ", decl);
			}
		}
	}

	// Check for duplicate/variables labels in the entire program
	private void checkNoDuplicateProgLabels() throws SemanticAnalysisException {

		Set<String> labels = new HashSet<String>();

		for (Declaration decl : progAST.fetchDeclarations()) {
			String label = decl.ObtainSymbolName().toString();

			if (labels.contains(label)) {
				throw new SemanticAnalysisException("It is prohibited to have duplicate labels within the program"
						+ label + " ", decl);
			} else {
				labels.add(label);
			}
		}
	}

	// Populate funcMap with function declarations and progVarMap with program variable types
	private void setProgVarAndFuncMaps() {

		for (Declaration decl : progAST.fetchDeclarations()) {

			String label = decl.ObtainSymbolName().toString();

			if (decl instanceof FunctionDecl) {
				FunctionDecl funcDecl = (FunctionDecl) decl;
				funcMap.put(label, funcDecl);

			} else if (decl instanceof VariableDecl) {
				VariableDecl varDecl = (VariableDecl) decl;
				progVarMap.put(label, varDecl.fetchType());
			}
		}
	}
}
