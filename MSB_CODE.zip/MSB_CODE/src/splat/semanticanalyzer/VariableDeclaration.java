package splat.semanticanalyzer;

public class VariableDeclaration {
}
