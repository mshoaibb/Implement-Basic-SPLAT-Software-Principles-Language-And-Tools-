package splat.executor;

import splat.parser.elements.extraelements.Type;

/**
 * Boolean data wrapper class in the Splat language, extending the Value class.
 */
public class BoolDataWrapper extends Value {

    /**
     * Constructs a BoolDataWrapper with the given boolean value and data type.
     *
     * @param boolValue      The boolean value to be wrapped.
     * @param customDataType The data type of the boolean value.
     */
    public BoolDataWrapper(Boolean boolValue, Type customDataType) {
        super(null, null, boolValue, customDataType);
    }

    /**
     * Retrieves the boolean value wrapped by this BoolDataWrapper.
     *
     * @return The boolean value.
     */
    public Boolean retrieveBooleanValue() {
        return super.getBooleanValue();
    }

    /**
     * Retrieves the data type of the boolean value.
     *
     * @return The data type.
     */
    public Type retrieveType() {
        return super.getType();
    }

}
