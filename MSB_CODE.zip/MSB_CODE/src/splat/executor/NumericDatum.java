package splat.executor;

import splat.parser.elements.extraelements.Type;

/**
 * Class representing integer values in the Splat language.
 * Extends the Value class.
 */
public class NumericDatum extends Value {

    /**
     * Constructor for IntegerValue with the given integer value and data type.
     *
     * @param integerValue The integer value to be wrapped.
     * @param customDataType The data type of the integer value.
     */
    public NumericDatum(Integer integerValue, Type customDataType) {
        super(integerValue, null, null, customDataType);
    }

    /**
     * Obtains the integer value wrapped by this IntegerValue.
     *
     * @return The integer value.
     */
    public Integer obtainIntegerValue() {
        return super.getIntegerValue();
    }

    /**
     * Obtains the data type of the integer value.
     *
     * @return The data type.
     */
    public Type obtainType() {
        return super.getType();
    }
}
