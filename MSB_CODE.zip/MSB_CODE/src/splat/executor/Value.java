package splat.executor;

import splat.parser.elements.extraelements.Type;

public abstract class Value {

    private Integer integerValue;
    private String stringValue;
    private Boolean booleanValue;
    private Type dataType;

	// TODO: Implement me!

    public Value(Integer integerValue, String stringValue, Boolean booleanValue, Type dataType) {
        this.integerValue = integerValue;
        this.stringValue = stringValue;
        this.booleanValue = booleanValue;
        this.dataType = dataType;
    }

    public Integer getIntegerValue() {
        return integerValue;
    }

    public void setIntegerValue(Integer integerValue) {
        this.integerValue = integerValue;
    }

    public String getStringValue() {
        return stringValue;
    }

    public void setStringValue(String stringValue) {
        this.stringValue = stringValue;
    }

    public Boolean getBooleanValue() {
        return booleanValue;
    }

    public void setBooleanValue(Boolean booleanValue) {
        this.booleanValue = booleanValue;
    }

    public Type getType() {
        return dataType;
    }

    public void setType(Type dataType) {
        this.dataType = dataType;
    }
}
