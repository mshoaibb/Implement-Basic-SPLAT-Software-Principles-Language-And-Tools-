package splat.executor;

import splat.parser.elements.*;
import splat.parser.elements.extraelements.Type;
import splat.parser.elements.FunctionDecl;
import splat.parser.elements.ProgramAST;

import java.util.HashMap;
import java.util.Map;

public class Executor {

	private ProgramAST progAST;

	private Map<String, FunctionDecl> funcMap = new HashMap<>();
	private Map<String, Value> progVarMap = new HashMap<>();

	public Executor(ProgramAST progAST) {

		this.progAST = progAST;
	}

	/**
	 * Runs the program by executing each statement in the program's body.
	 *
	 * @throws ExecutionException if an error occurs during execution.
	 */
	public void runProgram() throws ExecutionException {
		// Set up the maps needed for executing function calls and storing program variable values
		setMaps();

		try {
			// Go through and execute each of the statements
			for (Statement stmt : progAST.getStmts()) {
				stmt.execute(funcMap, progVarMap);
			}

			// We should never have to catch this exception here, since the
			// main program body cannot have returns
		} catch (ReturnFromCall ex) {
			System.out.println("Internal error!!! The main program body "
					+ "cannot have a return statement -- this should have "
					+ "been caught during semantic analysis!");

			throw new ExecutionException("Internal error -- fix your "
					+ "semantic analyzer!", -1, -1);
		}
	}

	/**
	 * Sets up the maps required for function declarations and program variables.
	 */
	private void setMaps() {
		// TODO: Use setMaps() from SemanticAnalyzer as a guide
		progAST.fetchDeclarations().forEach(descriptor -> {
			String tag = descriptor.ObtainSymbolName();

			if (descriptor instanceof FunctionDecl) {
				funcMap.put(tag, (FunctionDecl) descriptor);
			} else if (descriptor instanceof VariableDecl) {
				VariableDecl varDecl = (VariableDecl) descriptor;
				Type varDataType = varDecl.fetchType();

				progVarMap.put(tag, switch (varDataType) {
					case Integer -> new NumericDatum(0, Type.Integer);
					case String -> new TextDataEntity("", Type.String);
					case Boolean -> new BoolDataWrapper(false, Type.Boolean);
					case Void -> null;
				});
			}
		});
	}
}
