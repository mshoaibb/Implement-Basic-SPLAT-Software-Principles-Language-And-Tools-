package splat.executor;

import splat.parser.elements.extraelements.Type;

/**
 * String data wrapper class in the Splat language, extending the Value class.
 */
public class TextDataEntity extends Value {

    /**
     * Constructor for StringValue with the given string value and data type.
     *
     * @param strValue       The string value to be wrapped.
     * @param customDataType The data type of the string value.
     */
    public TextDataEntity(String strValue, Type customDataType) {
        super(null, strValue, null, customDataType);
    }

    /**
     * Obtains the string value wrapped by this StringValue.
     *
     * @return The string value.
     */
    public String obtainStringValue() {
        return super.getStringValue();
    }

    /**
     * Obtains the data type of the string value.
     *
     * @return The data type.
     */
    public Type obtainType() {
        return super.getType();
    }
}
