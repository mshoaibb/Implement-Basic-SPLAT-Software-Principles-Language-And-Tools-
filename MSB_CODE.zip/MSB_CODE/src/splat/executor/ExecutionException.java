package splat.executor;

import splat.SplatException;
import splat.parser.elements.extraelements.ArithmeticLogicExpression;

public class ExecutionException extends SplatException {

	public ExecutionException(String msg, ArithmeticLogicExpression elem) {
		super(msg, elem.getLine(), elem.getColumn());
	}
	
	public ExecutionException(String msg, int line, int column) {
		super(msg, line, column);
	}
}
