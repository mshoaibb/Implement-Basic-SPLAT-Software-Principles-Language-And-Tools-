package splat.parser.elements;

import java.util.List;
import splat.lexer.Token;
import java.util.ArrayList;
import splat.parser.elements.extraelements.Type;

public class FunctionDecl extends Declaration {

	private Type returnDataType;
	private List<VariableDecl> argument;
	private List<VariableDecl> element;
	private List<Statement> command;

	public FunctionDecl(Token tok) {
		super(tok);
		this.returnDataType = returnDataType;
		this.argument = argument;
		this.element = (element == null) ? new ArrayList<>() : element;
		this.command = command;
	}

	public Type fetchType() {
		return returnDataType;
	}

	public void assignOutputType(Type returnDataType) {
		this.returnDataType = returnDataType;
	}

	public List<VariableDecl> retrieveParam() {
		return argument;
	}

	public void setArgument(List<VariableDecl> argument) {
		this.argument = argument;
	}

	public List<VariableDecl> fetchelement() {
		return element;
	}

	public void setElement(List<VariableDecl> element) {
		this.element = (element == null) ? new ArrayList<>() : element;
	}

	public List<Statement> getState() {
		return command;
	}

	public void setCommand(List<Statement> commands) {
		this.command = commands;
	}

	@Override
	public String toString() {
		StringBuilder result = new StringBuilder();
		result.append(ObtainSymbolName()).append(" (");
		if (retrieveParam() != null && !retrieveParam().isEmpty()) {
			result.append(retrieveParam());
		}
		result.append(") : ").append(fetchType()).append(" is ");
		if (fetchelement() != null && !fetchelement().isEmpty()) {
			result.append(fetchelement());
		}
		result.append(" begin ");
		if (getState() != null && !getState().isEmpty()) {
			result.append(getState());
		}
		result.append(" end;");
		return result.toString();
	}
}
