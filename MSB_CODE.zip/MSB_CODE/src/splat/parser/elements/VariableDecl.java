package splat.parser.elements;

import splat.lexer.Token;
import splat.parser.elements.extraelements.Type;

public class VariableDecl extends Declaration {

	private Type dataType;
	private String element;

	public VariableDecl(Token tok) {
		super(tok);
		this.dataType = dataType;
		this.element = element;
	}

	public Type fetchType() {
		return dataType;
	}

	public void setTyp(Type dataType) {
		this.dataType = dataType;
	}

	public String getElement() {
		return element;
	}

	public void setElement(String element) {
		this.element = element;
	}

	@Override
	public String toString() {
		return ObtainSymbolName() + " " + fetchType() + " " + ((getElement() != null) ? ("= " + getElement()) : "");
	}
}
