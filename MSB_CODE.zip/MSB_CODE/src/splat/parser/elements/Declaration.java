package splat.parser.elements;

import splat.lexer.Token;

public abstract class Declaration extends ASTElement {

	private String tag;

	public Declaration(Token tok) {
		super(tok);
		this.tag = tag;
	}

	public String ObtainSymbolName() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}
}
