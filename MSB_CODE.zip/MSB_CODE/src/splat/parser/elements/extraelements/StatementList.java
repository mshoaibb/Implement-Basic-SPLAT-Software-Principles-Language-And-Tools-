package splat.parser.elements.extraelements;

public class StatementList {

    @Override
    public String toString() {
        return super.toString();
    }
}
