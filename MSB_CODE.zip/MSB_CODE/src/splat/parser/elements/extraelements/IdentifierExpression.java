package splat.parser.elements.extraelements;

import splat.executor.Value;
import splat.lexer.Token;
import splat.parser.elements.Expression;
import splat.parser.elements.FunctionDecl;
import java.util.Map;
import splat.semanticanalyzer.SemanticAnalysisException;

public class IdentifierExpression extends Expression {

    private String tag;

    public IdentifierExpression(Token token, String tag) {
        super(token);
        this.tag = tag;
    }

    @Override
    public Type analyzeAndGetType(Map<String, FunctionDecl> funcMap, Map<String, Type> varAndParamMap) throws SemanticAnalysisException {
        if (!varAndParamMap.containsKey(getTag())) {
            throw new SemanticAnalysisException("Element is not initialized" + tag + " ", this);
        }

        Type variableType = varAndParamMap.get(getTag());
        return mapVariableType(variableType);
    }

    private Type mapVariableType(Type dataType) throws SemanticAnalysisException {
        switch (dataType) {
            case Integer:
                return Type.Integer;
            case String:
                return Type.String;
            case Boolean:
                return Type.Boolean;
            // Add more cases for other data types if needed
            default:
                throw new SemanticAnalysisException("Unrecognized data type " + dataType, this);
        }
    }


    @Override
    public Value evaluate(Map<String, FunctionDecl> funcMap, Map<String, Value> varAndParamMap) {
        return varAndParamMap.get(tag);
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }


    @Override
    public String toString() {
        return "Identifier{" +
                "label='" + tag + '\'' +
                '}';
    }
}
