package splat.parser.elements.extraelements;

import splat.executor.ExecutionException;
import splat.executor.ReturnFromCall;
import splat.executor.Value;
import splat.executor.BoolDataWrapper;
import splat.executor.NumericDatum;
import splat.executor.TextDataEntity;
import splat.lexer.Token;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import splat.parser.elements.*;
import splat.semanticanalyzer.SemanticAnalysisException;

/**
 * DynamicOperationHandler class represents a dynamic operation in the Splat programming language.
 */
public class DynamicOperationHandlerExpression extends Expression {

    private String functionTag;
    private List<Expression> functionArguments;

    public DynamicOperationHandlerExpression(Token token) {
        super(token);
    }

    /**
     * Constructor for DynamicOperationHandler class.
     *
     * @param token             The token associated with the dynamic operation.
     * @param functionTag     The label of the function.
     * @param functionArguments The list of function arguments.
     */
    public DynamicOperationHandlerExpression(Token token, String functionTag, List<Expression> functionArguments) {
        super(token);
        this.functionTag = functionTag;
        this.functionArguments = functionArguments;
    }

    @Override
    public Type analyzeAndGetType(Map<String, FunctionDecl> functionMap, Map<String, Type> variableAndParamMap) throws SemanticAnalysisException {

        if (!functionMap.containsKey(this.getFunctionTag())) {
            throw new SemanticAnalysisException("Called function does not exist", this);
        }

        List<Expression> arguments = this.getFunctionArguments();

        FunctionDecl declaration = functionMap.get(functionTag);

        if (declaration.retrieveParam() == null && arguments.size() > 0) {
            throw new SemanticAnalysisException("Function does not accept any parameters", this);
        }

        int i = 0;
        do {
            if (declaration.retrieveParam().get(i).fetchType() != arguments.get(i).analyzeAndGetType(functionMap, variableAndParamMap)) {
                throw new SemanticAnalysisException("Type of the argument and type of parameter in declaration does not match", this);
            }
            i++;
        } while (i < arguments.size());


        return functionMap.get(this.getFunctionTag()).fetchType();
    }

    @Override
    public Value evaluate(Map<String, FunctionDecl> functionMap, Map<String, Value> variableAndParamMap) throws ExecutionException {

        FunctionDecl declaration = functionMap.get(this.getFunctionTag());

        Map<String, Value> localContextMap = new HashMap<>();

        List<Expression> arguments = this.getFunctionArguments();

        int indexArgument = 0;

        do {
            VariableDecl variable = declaration.retrieveParam().get(indexArgument);
            Value value = arguments.get(indexArgument).evaluate(functionMap, variableAndParamMap);

            switch (variable.fetchType()) {
                case Integer:
                    localContextMap.put(variable.ObtainSymbolName(), new NumericDatum(value.getIntegerValue(), Type.Integer));
                    break;
                case String:
                    localContextMap.put(variable.ObtainSymbolName(), new TextDataEntity(value.getStringValue(), Type.String));
                    break;
                case Boolean:
                    localContextMap.put(variable.ObtainSymbolName(), new BoolDataWrapper(value.getBooleanValue(), Type.Boolean));
                    break;
                // Add more cases for other data types if needed
            }

            indexArgument++;
        } while (indexArgument < declaration.retrieveParam().size());



        for (VariableDecl variable : declaration.fetchelement()) {
            switch (variable.fetchType()) {
                case Integer:
                    localContextMap.put(variable.ObtainSymbolName(), new NumericDatum(0, Type.Integer));
                    break;
                case String:
                    localContextMap.put(variable.ObtainSymbolName(), new TextDataEntity("", Type.String));
                    break;
                case Boolean:
                    localContextMap.put(variable.ObtainSymbolName(), new BoolDataWrapper(false, Type.Boolean));
                    break;
                // Add more cases for other data types if needed
            }
        }


        boolean returnOccurred = false;

        for (Statement stat : declaration.getState()) {
            if (!returnOccurred) {
                try {
                    stat.execute(functionMap, localContextMap);
                } catch (ReturnFromCall returnFromCall) {
                    returnOccurred = true;
                    return returnFromCall.getReturnVal();
                }
            }
        }

        return null;

    }

    /**
     * Gets the list of function arguments.
     *
     * @return The list of function arguments.
     */
    public List<Expression> getFunctionArguments() {
        return functionArguments;
    }

    /**
     * Gets the label of the function.
     *
     * @return The label of the function.
     */
    public String getFunctionTag() {
        return functionTag;
    }

    @Override
    public String toString() {
        return "DynamicOperationHandler{" +
                "functionLabel='" + functionTag + '\'' +
                ", functionArguments=" + functionArguments +
                '}';
    }
}
