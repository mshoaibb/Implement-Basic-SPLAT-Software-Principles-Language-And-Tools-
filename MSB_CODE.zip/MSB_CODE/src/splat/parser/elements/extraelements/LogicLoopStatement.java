package splat.parser.elements.extraelements;

import splat.executor.ExecutionException;
import splat.executor.ReturnFromCall;
import splat.executor.Value;
import splat.lexer.Token;
import splat.parser.elements.Expression;
import splat.parser.elements.FunctionDecl;
import splat.parser.elements.Statement;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import splat.semanticanalyzer.SemanticAnalysisException;
public class LogicLoopStatement extends Statement {

    private Expression Operand;
    private List<Statement> bodyStats;

    public LogicLoopStatement(Token token) {
        super(token);
    }

    @Override
    public void analyze(Map<String, FunctionDecl> functionMap, Map<String, Type> declarationMapping) throws SemanticAnalysisException {
        // Check condition type
        if (Type.Boolean != Operand.analyzeAndGetType(functionMap, declarationMapping)) {
            throw new SemanticAnalysisException("Invalid boolean condition", this);
        }

        // Check body statements
        Iterator<Statement> iterator = bodyStats.iterator();

        do {
            if (iterator.hasNext()) {
                Statement stat = iterator.next();
                stat.analyze(functionMap, declarationMapping);
            } else {
                break; // exit the loop when there are no more elements
            }
        } while (true);

    }

    @Override
    public void execute(Map<String, FunctionDecl> functionMap, Map<String, Value> variableAndParameterMap) throws ReturnFromCall, ExecutionException {
        Value evaluatedCondition = Operand.evaluate(functionMap, variableAndParameterMap);

        // Functional alternative to while loop
        while (evaluatedCondition.getBooleanValue()) {
            bodyStats.forEach(statement -> {
                try {
                    statement.execute(functionMap, variableAndParameterMap);
                } catch (ReturnFromCall | ExecutionException exe) {
                    // Handle exceptions if needed
                    exe.printStackTrace();
                }
            });
            evaluatedCondition = Operand.evaluate(functionMap, variableAndParameterMap);
        }
    }

    public Expression getOperand() {
        return Operand;
    }

    public void setOperand(Expression operand) {
        this.Operand = operand;
    }

    public List<Statement> getBodyStatements() {
        return bodyStats;
    }

    public void setBodyStatements(List<Statement> bodyStats) {
        this.bodyStats = bodyStats;
    }

    @Override
    public String toString() {
        return "LogicLoop{" +
                "condition=" + Operand +
                ", bodyStats=" + bodyStats +
                '}';
    }
}
