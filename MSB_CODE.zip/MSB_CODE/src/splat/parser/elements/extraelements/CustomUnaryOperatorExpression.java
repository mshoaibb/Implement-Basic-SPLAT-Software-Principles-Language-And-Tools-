package splat.parser.elements.extraelements;

import splat.executor.BoolDataWrapper;
import splat.executor.ExecutionException;
import splat.executor.Value;
import splat.executor.NumericDatum;
import splat.lexer.Token;
import splat.parser.elements.Expression;
import splat.parser.elements.FunctionDecl;
import splat.semanticanalyzer.SemanticAnalysisException;

import java.util.Arrays;
import java.util.Map;

/**
 * Represents a custom unary operator expression in the SPLAT language.
 */
public class CustomUnaryOperatorExpression extends Expression {

    private String customOp;
    private Expression customOperandExpr;

    /**
     * Constructs a CustomUnaryOperator instance with the given custom token.
     *
     * @param customToken The custom token representing the unary operator.
     */
    public CustomUnaryOperatorExpression(Token customToken) {
        super(customToken);
    }

    /**
     * Constructs a CustomUnaryOperator instance with the given custom token, operator, and operand expression.
     *
     * @param customToken       The custom token representing the unary operator.
     * @param customOp          The custom unary operator.
     * @param customOperandExpr The expression serving as the operand for the unary operator.
     */
    public CustomUnaryOperatorExpression(Token customToken, String customOp, Expression customOperandExpr) {
        super(customToken);
        this.customOp = customOp;
        this.customOperandExpr = customOperandExpr;
    }

    @Override
    public Type analyzeAndGetType(Map<String, FunctionDecl> funcMap, Map<String, Type> varAndParamMap)
            throws SemanticAnalysisException {

        // Analyze the data type of the operand expression
        Type operandExprDataType = customOperandExpr.analyzeAndGetType(funcMap, varAndParamMap);

        // Validate the supported unary operators
        if (!Arrays.asList("not", "-").contains(this.getCustomOp())) {
            throw new SemanticAnalysisException("Unsupported unary operator", this);
        }

        // Check if the operand expression type is Boolean or Integer
        if (operandExprDataType != Type.Boolean && operandExprDataType != Type.Integer) {
            throw new SemanticAnalysisException("Type for unary operator must be Boolean or Integer", this);
        }

        return operandExprDataType;
    }

    @Override
    public Value evaluate(Map<String, FunctionDecl> funcMap, Map<String, Value> varAndParamMap) throws ExecutionException {

        // Evaluate the operand expression
        Value evaluated = this.getCustomOperandExpr().evaluate(funcMap, varAndParamMap);

        // Apply the corresponding unary operation
        if (this.getCustomOp().equals("not")) {
            return alternativeNotImplementation(evaluated.getBooleanValue());
        } else {
            return alternativeNegationImplementation(evaluated.getIntegerValue());
        }
    }

    /**
     * Implements an alternative "not" operation for boolean values.
     *
     * @param value The boolean value to be negated.
     * @return The result of the negation operation.
     */
    private Value alternativeNotImplementation(Boolean value) {
        return new BoolDataWrapper(!value, Type.Boolean);
    }

    /**
     * Implements an alternative negation operation for integer values.
     *
     * @param value The integer value to be negated.
     * @return The result of the negation operation.
     */
    private Value alternativeNegationImplementation(Integer value) {
        return new NumericDatum(-value, Type.Integer);
    }

    /**
     * Gets the custom unary operator.
     *
     * @return The custom unary operator as a string.
     */
    public String getCustomOp() {
        return customOp;
    }

    /**
     * Sets the custom unary operator.
     *
     * @param customOp The custom unary operator to set.
     */
    public void setCustomOp(String customOp) {
        this.customOp = customOp;
    }

    /**
     * Gets the expression serving as the operand for the unary operator.
     *
     * @return The operand expression.
     */
    public Expression getCustomOperandExpr() {
        return customOperandExpr;
    }

    /**
     * Sets the expression serving as the operand for the unary operator.
     *
     * @param customOperandExpr The operand expression to set.
     */
    public void setCustomOperandExpr(Expression customOperandExpr) {
        this.customOperandExpr = customOperandExpr;
    }

    @Override
    public String toString() {
        return "CustomUnaryOperator{" +
                "customOp='" + customOp + '\'' +
                ", customOperandExpr=" + customOperandExpr +
                '}';
    }
}
