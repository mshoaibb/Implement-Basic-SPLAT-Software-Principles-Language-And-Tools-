package splat.parser.elements.extraelements;

import splat.executor.*;
import splat.lexer.Token;
import splat.parser.elements.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import splat.semanticanalyzer.SemanticAnalysisException;

public class InvokeFunctionStatement extends Statement {

    private String tag;
    private List<Expression> arg;

    public InvokeFunctionStatement(Token token) {
        super(token);
    }

    @Override
    public void analyze(Map<String, FunctionDecl> funcMap, Map<String, Type> varAndParamMap) throws SemanticAnalysisException {

        List<Expression> arg = this.getArg();
        FunctionDecl decl = funcMap.get(tag);
        if (funcMap.containsKey(this.getTag())) {
            // Proceed with the function invocation logic
        } else {
            throw new SemanticAnalysisException("Invalid function invocation",
                    new FunctionDecl(new Token(tag, super.getLine(), super.getColumn()))
            );
        }



        int i = 0;
        while (i < decl.retrieveParam().size()) {
            VariableDecl parameter = decl.retrieveParam().get(i);
            Expression argument = arg.get(i);

            if (!parameter.fetchType().equals(argument.analyzeAndGetType(funcMap, varAndParamMap))) {
                throw new SemanticAnalysisException("Incompatible types for argument and parameter in declaration", this);
            }


            i++;
        }

    }

    @Override
    public void execute(Map<String, FunctionDecl> funcMap, Map<String, Value> vAPM) throws ReturnFromCall, ExecutionException {

        FunctionDecl decl = funcMap.get(this.getTag());

        // ------- Store variables and parameters to track their values

        Map<String, Value> variableContextMap = new HashMap<>();

        List<Expression> arguments = this.getArg();
        int indexArgument = 0;

        for (VariableDecl var : decl.retrieveParam()) {
            Value value = arguments.get(indexArgument++).evaluate(funcMap, vAPM);

            variableContextMap.put(var.ObtainSymbolName(), createValueWithType(var.fetchType(), value));
        }

        for (VariableDecl var : decl.fetchelement()) {
            variableContextMap.put(var.ObtainSymbolName(), createDefaultValueWithType(var.fetchType()));
        }

        // executing statements of a function

        try {
            for (Statement stmt : decl.getState()) {
                stmt.execute(funcMap, variableContextMap);
            }
        } catch (ReturnFromCall returnFromCall) {

        }
    }

    private Value createValueWithType(Type dataType, Value value) {
        switch (dataType) {
            case Integer:
                return new NumericDatum(value.getIntegerValue(), Type.Integer);
            case String:
                return new TextDataEntity(value.getStringValue(), Type.String);
            case Boolean:
                return new BoolDataWrapper(value.getBooleanValue(), Type.Boolean);
            default:
                throw new IllegalArgumentException("Unsupported type: " + dataType);
        }
    }

    private Value createDefaultValueWithType(Type dataType) {
        switch (dataType) {
            case Integer:
                return new NumericDatum(0, Type.Integer);
            case String:
                return new TextDataEntity("", Type.String);
            case Boolean:
                return new BoolDataWrapper(false, Type.Boolean);
            default:
                throw new IllegalArgumentException("Unsupported type: " + dataType);
        }
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public List<Expression> getArg() {
        return arg;
    }

    public void setArg(List<Expression> arg) {
        this.arg = arg;
    }

    @Override
    public String toString() {
        return "InvokeFunctionStat{" +
                "label='" + tag + '\'' +
                ", arguments=" + arg +
                '}';
    }
}
