package splat.parser.elements.extraelements;

public class FunctionDeclaration {

    @Override
    public String toString() {
        return super.toString();
    }
}
