package splat.parser.elements.extraelements;

import splat.lexer.Token;
import splat.parser.elements.Expression;
import splat.parser.elements.FunctionDecl;
import splat.parser.elements.Statement;
import java.util.Map;
import splat.executor.ExecutionException;
import splat.executor.ReturnFromCall;
import splat.executor.Value;
import splat.semanticanalyzer.SemanticAnalysisException;

public class ResultStatement extends Statement {

    private Expression exp;

    public ResultStatement(Token tokn) {
        super(tokn);
    }

    @Override
    public void analyze(Map<String, FunctionDecl> funcMap, Map<String, Type> variableContextMap) throws SemanticAnalysisException {

        if (this.getE() != null) {


        } else if (variableContextMap.get("0return") != Type.Void) {
            throw new SemanticAnalysisException("Invalid return type (void expected)", this);

        } else {
            return;
        }


        Type expDaTy = exp.analyzeAndGetType(funcMap, variableContextMap);

        if (variableContextMap.get("0return") != expDaTy) {
            throw new SemanticAnalysisException("Incompatible return types", this);
        }

        variableContextMap.put("0ActualReturn", expDaTy);
    }

    @Override
    public void execute(Map<String, FunctionDecl> funcMap, Map<String, Value> varAndParamMap) throws ReturnFromCall, ExecutionException {

        Value calc = (this.getE() != null) ? exp.evaluate(funcMap, varAndParamMap) : null;
        throw new ReturnFromCall(calc);

    }

    public Expression getE() {
        return exp;
    }

    public void setExp(Expression exp) {
        this.exp = exp;
    }

    @Override
    public String toString() {
        return "ResultStat{" +
                "exp=" + exp +
                '}';
    }
}
