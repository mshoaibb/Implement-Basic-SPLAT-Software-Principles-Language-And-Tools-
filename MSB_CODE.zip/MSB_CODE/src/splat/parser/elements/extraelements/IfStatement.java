package splat.parser.elements.extraelements;

import splat.executor.ExecutionException;
import splat.executor.ReturnFromCall;
import splat.executor.Value;
import splat.lexer.Token;
import splat.parser.elements.Expression;
import splat.parser.elements.FunctionDecl;
import splat.parser.elements.Statement;
import splat.semanticanalyzer.SemanticAnalysisException;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class IfStatement extends Statement {

    private Expression exp;
    private List<Statement> stateT;
    private List<Statement> stateE;

    public IfStatement(Token tok) {
        super(tok);
    }

    @Override
    public void analyze(Map<String, FunctionDecl> funcMap, Map<String, Type> varAndParamMap) throws SemanticAnalysisException {

        // Checking for expression

        if (!(Type.Boolean == exp.analyzeAndGetType(funcMap, varAndParamMap))) {
            throw new SemanticAnalysisException("Invalid boolean expression", this);
        }

        // Checking for statements after then

        Iterator<Statement> iterator = stateT.iterator();
        while (iterator.hasNext()) {
            Statement stat = iterator.next();
            stat.analyze(funcMap, varAndParamMap);
        }

        if (stateE != null) {

            int index = 0;
            do {
                if (index < stateE.size()) {
                    Statement stat = stateE.get(index);
                    stat.analyze(funcMap, varAndParamMap);
                    index++;
                } else {
                    break;
                }
            } while (true);

        }
    }

    @Override
    public void execute(Map<String, FunctionDecl> funcMap, Map<String, Value> varAndParamMap) throws ReturnFromCall, ExecutionException {

        Value evaluated = exp.evaluate(funcMap,varAndParamMap);

        if (evaluated.getBooleanValue()) {

            Iterator<Statement> iterator = stateT.iterator();
            while (iterator.hasNext()) {
                Statement stmt = iterator.next();
                stmt.execute(funcMap, varAndParamMap);
            }


        } else if (this.getnStateExp() != null) {

            if (stateE != null) {
                Iterator<Statement> iterator = stateE.iterator();
                do {
                    if (iterator.hasNext()) {
                        Statement stmt = iterator.next();
                        stmt.execute(funcMap, varAndParamMap);
                    } else {
                        break;
                    }
                } while (true);
            }


        }
    }

    public Expression getExp() {
        return exp;
    }

    public void setExp(Expression exp) {
        this.exp = exp;
    }

    public List<Statement> getStatT() {
        return stateT;
    }

    public void setState(List<Statement> statementsThen) {
        this.stateT = statementsThen;
    }

    public List<Statement> getnStateExp() {
        return stateE;
    }

    public void setStateExp(List<Statement> statementsElse) {
        this.stateE = statementsElse;
    }

    @Override
    public String toString() {
        return "IfStat{" +
                "exp=" + exp +
                ", statementsThen=" + stateT +
                ", statementsElse=" + stateE +
                '}';
    }

}
