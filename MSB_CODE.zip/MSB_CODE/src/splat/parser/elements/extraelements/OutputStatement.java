package splat.parser.elements.extraelements;

import splat.executor.ExecutionException;
import splat.executor.ReturnFromCall;
import splat.executor.Value;
import splat.lexer.Token;
import splat.parser.elements.Expression;
import splat.parser.elements.FunctionDecl;
import splat.parser.elements.Statement;
import java.util.Map;
import splat.semanticanalyzer.SemanticAnalysisException;


public class OutputStatement extends Statement {

    private Expression exp;

    public OutputStatement(Token token) {
        super(token);
    }

    @Override
    public void analyze(Map<String, FunctionDecl> funcMap, Map<String, Type> vAPM) throws SemanticAnalysisException {
        exp.analyzeAndGetType(funcMap, vAPM);
    }

    @Override
    public void execute(Map<String, FunctionDecl> funcMap, Map<String, Value> vAPM) throws ReturnFromCall, ExecutionException {
        Value value = exp.evaluate(funcMap, vAPM);

        switch (value.getType()) {
            case String:
                System.out.printf(value.getStringValue().substring(1, value.getStringValue().length() - 1));
                break;
            case Boolean:
                System.out.print(value.getBooleanValue());
                break;
            case Integer:
                System.out.print(value.getIntegerValue());
                break;
            // Add cases for other types if needed
            default:
                // Handle other types as needed
        }
    }

    public Expression getExp() {
        return exp;
    }

    public void setExpr(Expression exp) {
        this.exp = exp;
    }

    @Override
    public String toString() {
        return "OutputStat{" +
                "exp=" + exp +
                '}';
    }
}
