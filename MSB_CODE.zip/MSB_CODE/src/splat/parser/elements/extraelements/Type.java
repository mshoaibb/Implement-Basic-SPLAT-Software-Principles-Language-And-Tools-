package splat.parser.elements.extraelements;

public enum Type {

    Integer, String, Boolean, Void;

    @Override
    public java.lang.String toString() {
        return super.toString();
    }
}
