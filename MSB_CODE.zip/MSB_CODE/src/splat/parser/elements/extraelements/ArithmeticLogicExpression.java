package splat.parser.elements.extraelements;

import splat.executor.ExecutionException;
import splat.executor.Value;
import splat.parser.elements.Expression;
import splat.parser.elements.FunctionDecl;
import splat.semanticanalyzer.SemanticAnalysisException;
import splat.executor.BoolDataWrapper;
import splat.executor.NumericDatum;
import splat.lexer.Token;

import java.util.Map;

public class ArithmeticLogicExpression extends Expression {

    private String Controller;
    private Expression leftOperand;
    private Expression rightOperand;

    public ArithmeticLogicExpression(Token token) {
        super(token);
    }

    public ArithmeticLogicExpression(Token token, String Controller, Expression leftOperand, Expression rightOperand) {
        super(token);
        this.Controller = Controller;
        this.leftOperand = leftOperand;
        this.rightOperand = rightOperand;
    }

    @Override
    public Type analyzeAndGetType(Map<String, FunctionDecl> funcMap, Map<String, Type> varAndParamMap) throws SemanticAnalysisException {

        Type leftDataType = this.retrieveLeftOperand().analyzeAndGetType(funcMap, varAndParamMap);
        Type rightDataType = this.acquireRightOp().analyzeAndGetType(funcMap, varAndParamMap);

        Type returnDataType = null;

        switch (this.retrieveController()) {
            case "and":
            case "or":
                if (leftDataType != Type.Boolean || rightDataType != Type.Boolean) {
                    throw new SemanticAnalysisException("Operands type for this type of operator must be Boolean", this);
                }
                returnDataType = Type.Boolean;
                break;
            case ">":
            case "<":
            case ">=":
            case "<=":
                if (leftDataType != Type.Integer || rightDataType != Type.Integer) {
                    throw new SemanticAnalysisException("Operands type for this type of operator must be Integer", this);
                }
                returnDataType = Type.Boolean;
                break;
            case "==":
                if (!(isValidEqualityType(leftDataType) && isValidEqualityType(rightDataType))) {
                    throw new SemanticAnalysisException("Operands type for this type of operator ('==') must match", this);
                }
                returnDataType = Type.Boolean;
                break;
            case "-":
            case "+":
            case "*":
            case "/":
            case "%":
                if (leftDataType != Type.Integer || rightDataType != Type.Integer) {
                    throw new SemanticAnalysisException("Operands type for this type of operator must be Integer", this);
                }
                returnDataType = Type.Integer;
                break;
            default:
                // Handle default case if needed
                break;
        }

        return returnDataType;
    }


    private boolean isValidEqualityType(Type dataType) {
        return dataType == Type.Integer || dataType == Type.Boolean || dataType == Type.String;
    }

    @Override
    public Value evaluate(Map<String, FunctionDecl> funcMap, Map<String, Value> varAndParamMap) throws ExecutionException {

        Expression leftTemp = this.retrieveLeftOperand();
        Value evaluatedLeft = leftTemp.evaluate(funcMap, varAndParamMap);

        Expression rightTemp = this.acquireRightOp();
        Value evaluatedRight = rightTemp.evaluate(funcMap, varAndParamMap);

        switch (this.retrieveController()) {
            case ">":
            case "<":
            case ">=":
            case "<=":
                return evaluateComparison(evaluatedLeft.getIntegerValue(), evaluatedRight.getIntegerValue());
            case "-":
            case "+":
            case "*":
            case "/":
            case "%":
                return evaluateArithmetic(evaluatedLeft.getIntegerValue(), evaluatedRight.getIntegerValue());
            case "and":
            case "or":
                return evaluateBool(evaluatedLeft.getBooleanValue(), evaluatedRight.getBooleanValue());
            case "==":
                return evaluateEx(evaluatedLeft, evaluatedRight);
            default:
                // Handle default case if needed
                return null;
        }
    }


    private Value evaluateComparison(Integer left, Integer right) throws ExecutionException {
        switch (this.retrieveController()) {
            case "<":
                return new BoolDataWrapper(left < right, Type.Boolean);
            case "<=":
                return new BoolDataWrapper(left <= right, Type.Boolean);
            case ">":
                return new BoolDataWrapper(left > right, Type.Boolean);
            case ">=":
                return new BoolDataWrapper(left >= right, Type.Boolean);
            default:
                throw new ExecutionException("Unsupported comparison operator", this);
        }
    }

    private Value evaluateArithmetic(Integer left, Integer right) throws ExecutionException {
        switch (this.retrieveController()) {
            case "-":
                return new NumericDatum(left - right, Type.Integer);
            case "+":
                return new NumericDatum(left + right, Type.Integer);
            case "*":
                return new NumericDatum(left * right, Type.Integer);
            case "/":
                return handleDivision(left, right);
            case "%":
                return handleModulus(left, right);
            default:
                throw new ExecutionException("Unsupported arithmetic operator", this);
        }
    }
    private Value handleDivision(Integer left, Integer right) throws ExecutionException {
        if (right == 0) {
            throw new ExecutionException("Value can not be divided by 0", this);
        }
        return new NumericDatum(left / right, Type.Integer);
    }

    private Value handleModulus(Integer left, Integer right) throws ExecutionException {
        if (right == 0) {
            throw new ExecutionException("Value can not be divided by 0", this);
        }
        return new NumericDatum(left % right, Type.Integer);
    }


    private Value evaluateBool(Boolean left, Boolean right) throws ExecutionException {
        String operator = this.retrieveController();

        if ("and".equals(operator)) {
            return new BoolDataWrapper(left && right, Type.Boolean);
        } else if ("or".equals(operator)) {
            return new BoolDataWrapper(left || right, Type.Boolean);
        } else {
            throw new ExecutionException("Unsupported boolean operator", this);
        }
    }
    private Value evaluateEx(Value left, Value right) throws ExecutionException {
        Type leftType = left.getType();
        Type rightType = right.getType();

        if (leftType != rightType) {
            throw new ExecutionException("Unsupported operand types for '==' operator", this);
        }

        switch (leftType) {
            case Integer:
                return new BoolDataWrapper(left.getIntegerValue().equals(right.getIntegerValue()), Type.Boolean);
            case Boolean:
                return new BoolDataWrapper(left.getBooleanValue().equals(right.getBooleanValue()), Type.Boolean);
            case String:
                return new BoolDataWrapper(left.getStringValue().equals(right.getStringValue()), Type.Boolean);
            default:
                throw new ExecutionException("Unsupported operand types for '==' operator", this);
        }
    }


    public String retrieveController() {
        return Controller;
    }

    public void setController(String controller) {
        this.Controller = controller;
    }

    public Expression retrieveLeftOperand() {
        return leftOperand;
    }

    public void setLeftOperand(Expression leftOperand) {
        this.leftOperand = leftOperand;
    }

    public Expression acquireRightOp() {
        return rightOperand;
    }

    public void setRightOperand(Expression rightOperand) {
        this.rightOperand = rightOperand;
    }

    @Override
    public String toString() {
        return "ArithmeticLogicExp{" +
                "operator='" + Controller + '\'' +
                ", leftOperand=" + leftOperand +
                ", rightOperand=" + rightOperand +
                '}';
    }
}
