package splat.parser.elements.extraelements;

import splat.lexer.Token;

public class CodeBlock {
    public CodeBlock(Token token) {
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
