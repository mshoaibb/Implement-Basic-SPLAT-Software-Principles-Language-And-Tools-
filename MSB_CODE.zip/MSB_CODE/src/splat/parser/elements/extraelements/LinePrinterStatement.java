package splat.parser.elements.extraelements;

import splat.executor.ReturnFromCall;
import splat.executor.Value;
import splat.lexer.Token;
import splat.parser.elements.FunctionDecl;
import splat.parser.elements.Statement;
import java.util.Map;
import splat.semanticanalyzer.SemanticAnalysisException;
public class LinePrinterStatement extends Statement {

    public LinePrinterStatement(Token tok) {
        super(tok);
    }

    @Override
    public void analyze(Map<String, FunctionDecl> funcMap, Map<String, Type> varAndParamMap) throws SemanticAnalysisException {
        // No analysis needed for LinePrinter, so simply return
        return;
    }

    @Override
    public void execute(Map<String, FunctionDecl> funcMap, Map<String, Value> varAndParamMap) throws ReturnFromCall {
        // Execute the LinePrinter statement by printing a new line
        System.out.println();
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
