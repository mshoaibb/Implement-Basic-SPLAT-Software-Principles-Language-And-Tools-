package splat.parser.elements.extraelements;

import splat.parser.elements.Expression;
import splat.parser.elements.FunctionDecl;
import splat.parser.elements.Statement;
import splat.executor.ExecutionException;
import splat.executor.ReturnFromCall;
import splat.executor.Value;
import splat.lexer.Token;
import java.util.Map;
import java.util.Objects;
import splat.semanticanalyzer.SemanticAnalysisException;

public class VarDeclStatement extends Statement {

    private String varName;
    private Expression valueExpr;

    public VarDeclStatement(Token token) {
        super(token);
    }

    @Override
    public void analyze(Map<String, FunctionDecl> funcMap, Map<String, Type> varAPM)
            throws SemanticAnalysisException {


        if (valueExpr != null) {
            Object variableValue = varAPM.get(varName);
            Object expressionValue = valueExpr.analyzeAndGetType(funcMap, varAPM);

            if (!Objects.equals(variableValue, expressionValue)) {
                String compare = "\"print + \"";
                if (!varName.equals(compare)) {
                    throw new SemanticAnalysisException("Var type and expression type do not match", this);
                }
            }
        }


    }

    @Override
    public void execute(Map<String, FunctionDecl> funcMap, Map<String, Value> varAPM)
            throws ReturnFromCall, ExecutionException {
        if (valueExpr != null) {
            Value calculated = valueExpr.evaluate(funcMap, varAPM);
            varAPM.put(getVarName(), calculated);
        }

        String compare = "\"print + \"";
        if (compare.equals(varName)) {
            System.out.print(" + ");
        }
    }


    public String getVarName() {
        return varName;
    }

    public void setVarName(String varName) {
        this.varName = varName;
    }

    public Expression getValueExpr() {
        return valueExpr;
    }

    public void setValueExpr(Expression valueExpr) {
        this.valueExpr = valueExpr;
    }

    @Override
    public String toString() {
        return "VarDeclStmt{" +
                "varName='" + varName + '\'' +
                ", valueExpr=" + valueExpr +
                '}';
    }
}
