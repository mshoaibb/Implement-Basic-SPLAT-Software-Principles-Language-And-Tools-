package splat.parser.elements.extraelements;

import splat.executor.BoolDataWrapper;
import splat.executor.Value;
import splat.executor.NumericDatum;
import splat.executor.TextDataEntity;
import splat.lexer.Token;
import splat.parser.elements.Expression;
import splat.parser.elements.FunctionDecl;

import java.util.Map;

public class AnnotatedTokenValueExpression extends Expression {

    private String customData;
    private Type customDataType;

    // Constructors
    public AnnotatedTokenValueExpression(Token customToken) {
        super(customToken);
    }

    public AnnotatedTokenValueExpression(Token customToken, String customData, Type customDataType) {
        super(customToken);
        setCustomData(customData);
        setCustomType(customDataType);
    }

    // Override method for type analysis
    @Override
    public Type analyzeAndGetType(Map<String, FunctionDecl> funcMap, Map<String, Type> varAndParamMap) {
        return getCustomType();
    }

    // Override method for expression
    // evaluation
    @Override
    public Value evaluate(Map<String, FunctionDecl> funcMap, Map<String, Value> varAndParamMap) {
        return evaluateCustomType();
    }

    // Private method for custom type evaluation
    private Value evaluateCustomType() {
        Type type = getCustomType();

        // Evaluate based on the custom type
        switch (type) {
            case Integer:
                return createIntegerValue();
            case String:
                return createStringValue();
            case Boolean:
                return createBooleanValue();
            default:
                return null; // Handle other types as needed
        }
    }

    // Private method to create an Integer value
    private NumericDatum createIntegerValue() {
        return new NumericDatum(Integer.parseInt(getCustomData()), getCustomType());
    }

    // Private method to create a String value
    private TextDataEntity createStringValue() {
        return new TextDataEntity(getCustomData(), getCustomType());
    }

    // Private method to create a Boolean value
    private BoolDataWrapper createBooleanValue() {
        return new BoolDataWrapper(Boolean.parseBoolean(getCustomData()), getCustomType());
    }

    // Getter method for custom data
    public String getCustomData() {
        return customData;
    }

    // Setter method for custom data
    public void setCustomData(String customData) {
        this.customData = customData;
    }

    // Getter method for custom type
    public Type getCustomType() {
        return customDataType;
    }

    // Setter method for custom type
    public void setCustomType(Type customDataType) {
        this.customDataType = customDataType;
    }

    @Override
    public String toString() {
        return "AnnotatedTokenValue{" +
                "customData='" + customData + '\'' +
                ", customDataType=" + customDataType +
                '}';
    }
}
