package splat.parser;

import java.util.regex.Pattern;
import java.util.List;
import splat.lexer.Token;
import splat.parser.elements.*;
import java.util.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import splat.parser.elements.extraelements.*;
import java.util.regex.Matcher;

/**
 * The Parser class is responsible for parsing tokens and constructing an Abstract Syntax Tree (AST).
 */
public class Parser {
	private List<Statement> commands = new ArrayList<>();
	private List<String> statements_of_intent = new ArrayList<>();

	/**
	 * Constructs a Parser instance with a list of tokens.
	 *
	 * @param tkn List of tokens to be parsed.
	 */

	private final Pattern StructureBlueprint = Pattern.compile("[a-zA-Z][a-zA-Z0-9_]*");
	private List<Token> tkn; // g
	private final Pattern namingConvention = Pattern.compile("^[1-9][0-9]*");
	public Parser(List<Token> tkn) {
		this.tkn = tkn;
	}
		private void checkNext(String expected) throws ParseException {
		Token tok = tkn.remove(0);
		if (!tok.getValue().equals(expected)) {
			throw new ParseException("Expected '" + expected + "', got '" + tok.getValue() + "'." + tok.getLine(), tok);
		}
	}

	private boolean peekNext(String expected) {
		return tkn.get(0).getValue().equals(expected);
	}
	private boolean peekTwoAhead(String expected) {
		return tkn.get(1).getValue().equals(expected);
	}
	/**
	 * Parses the entire program and constructs the ProgramAST.
	 *
	 * @return ProgramAST representing the parsed program.
	 * @throws ParseException If there is an error in parsing.
	 */
	public ProgramAST parse() throws ParseException {
		try {
			Token startTok = tkn.get(0);
			checkNext("program");
			List<Declaration> decls = parseDecls();
			checkNext("begin");
			List<Statement> stmts = parseStmts(new ArrayList<>());
			checkNext("end");
			checkNext(";");
			return new ProgramAST(decls, stmts, startTok);
		} catch (IndexOutOfBoundsException ex) {
			throw new ParseException("Unexpectedly reached the end of file.", -1, -1);
		}
	}
	/**
	 * Parses a list of statements.
	 *
	 * @return List of parsed statements.
	 * @throws ParseException If there is an error in parsing.
	 */
	private List<Declaration> parseDecls() throws ParseException {
		List<Declaration> decls = new ArrayList<>();
		while (!peekNext("begin")) {
			Declaration decl = parseDecl();
			decls.add(decl);
		}
		return decls;
	}

	private Declaration parseDecl() throws ParseException {
		if (peekTwoAhead(":")) {
			return parseVarDecl();
		} else if (peekTwoAhead("(")) {
			return parseFuncDecl();
		} else {
			Token tok = tkn.get(0);
			throw new ParseException("Declaration expected --> " + tok.getValue() + tok.getLine(), tok);
		}
	}

	private FunctionDecl parseFuncDecl() throws ParseException {
		Token tag = tkn.removeFirst();
		FunctionDecl FD1 = new FunctionDecl(tag);
		validateFunctionName(tag, FD1);

		// Parse parameters
		parseParameters(FD1);

		// Parse return type
		parseReturnType(FD1);

		// Parse local variables
		parseLocalVariables(FD1);

		// Parse function body
		parseFunctionBody(FD1);

		return FD1;
	}

	private void validateFunctionName(Token label, FunctionDecl FD1) throws ParseException {
		Matcher checkers = StructureBlueprint.matcher(label.getValue());
		if (checkers.matches()) {
			FD1.setTag(label.getValue());
		} else {
			throw new ParseException("\n" + "The function name does not align with the prescribed criteria", new Token(label.getValue(), label.getLine(), label.getColumn()));
		}
	}

	private void parseParameters(FunctionDecl FD1) throws ParseException {
		checkNext("(");

		List<VariableDecl> Inputs = new ArrayList<>();

		if (!peekNext(")")) {
			while (true) {
				if (peekNext(",")) {
					checkNext(",");
				}
				Inputs.add(parseVarDecl());

				if (!peekNext(",")) {
					break;
				}
			}
		}

		FD1.setArgument(Inputs);
		checkNext(")");
	}


	private void parseReturnType(FunctionDecl FD1) throws ParseException {
		checkNext(":");
		Token returnType = tkn.removeFirst();

		switch (returnType.getValue()) {
			case "String":
				FD1.assignOutputType(Type.String);
				break;
			case "Integer":
				FD1.assignOutputType(Type.Integer);
				break;
			case "Boolean":
				FD1.assignOutputType(Type.Boolean);
				break;
			case "void":
				FD1.assignOutputType(Type.Void);
				break;
			default:
				throw new ParseException("Invalid return type for the variable." + returnType.getValue(), returnType);
		}
		checkNext("is");
	}

	private void parseLocalVariables(FunctionDecl FD1) throws ParseException {
		while (!peekNext("begin")) {
			FD1.fetchelement().add(parseVarDecl());
		}
	}

	private void parseFunctionBody(FunctionDecl FD1) throws ParseException {
		checkNext("begin");

		if (!peekNext("end")) {
			FD1.setCommand(new ArrayList<>(parseStmts(new ArrayList<>())));
		}

		commands = new ArrayList<>();
		checkNext("end");
		checkNext(";");
	}


	private VariableDecl parseVarDecl() throws ParseException {
		Token labelToken = tkn.removeFirst();
		validateReservedKeywords(labelToken);

		checkNext(":");
		Token typeToken = tkn.removeFirst();

		VariableDecl varDecl = createVariableDecl(labelToken, typeToken);

		if (peekNext(";")) checkNext(";");

		statements_of_intent.add(varDecl.ObtainSymbolName());
		return varDecl;
	}

	private void validateReservedKeywords(Token labelToken) throws ParseException {
        List<String> reserved = Arrays.asList("while", "if", "print", "print_line", "return");
		if (reserved.contains(labelToken.getValue())) {
			throw new ParseException("\n" +
					"Variable name is not valid", labelToken);
		}
	}

	private VariableDecl createVariableDecl(Token labelToken, Token typeToken) throws ParseException {
		VariableDecl varDecl = new VariableDecl(typeToken);
		validateVariableName(labelToken, varDecl);

		switch (typeToken.getValue()) {
			case "String":
				varDecl.setTyp(Type.String);
				break;
			case "Integer":
				varDecl.setTyp(Type.Integer);
				break;
			case "Boolean":
				varDecl.setTyp(Type.Boolean);
				break;
			default:
				throw new ParseException("\n" +
						"Variable type does not comply with specified criteria. "
						+ typeToken.getValue() + " " + typeToken.getLine(), typeToken);
		}
		return varDecl;
	}

	private void validateVariableName(Token labelToken, VariableDecl varDecl) throws ParseException {
		Matcher Comparator = StructureBlueprint.matcher(labelToken.getValue());
		if (Comparator.matches()) {
			varDecl.setTag(labelToken.getValue());
		} else {
			throw new ParseException("Var name does not conform to defined standards.", labelToken);
		}
	}
	/**
	 * Parses a single statement and adds it to the list of statements.
	 *
	 * @param stats List to store the parsed statement.
	 * @return List of parsed statements.
	 * @throws ParseException If there is an error in parsing.
	 */
	private List<Statement> parseStmts(List<Statement> stats) throws ParseException {
		while(!peekNext("end") && !peekNext("else")) {
			parseStmt(stats);
		}
		return stats;
	}
	private List<Statement> parseStmt(List<Statement> stats) throws ParseException {
		if (peekNext("end")) {
			return stats;
		}

		if (peekNext("if")) {
			parseIfStatement(stats);
		} else if (peekNext("print")) {
			parsePrintStatement(stats);
		} else if (peekNext("print_line")) {
			parsePrintLineStatement(stats);
		} else if (peekNext("return")) {
			parseReturnStatement(stats);
		} else if (peekNext("while")) {
			parseWhileStatement(stats);
		} else if (!peekTwoAhead("(")) {
			parseVarDeclStatement(stats);
		} else if (peekTwoAhead("(")) {
			parseFunctionCallStatement(stats);
		} else {
			throw new ParseException("Exception thrown: BadStatementException", tkn.removeFirst());
		}

		return stats;
	}


	private void parseIfStatement(List<Statement> stats) throws ParseException {
		Token ifToken = tkn.removeFirst();
		IfStatement ifStatement = new IfStatement(ifToken);

		if (peekNext("(") && peekTwoAhead("(")) {
			checkNext("(");
		}

		Expression Former = null;

		while (!peekNext("then")) {
			Former = exp2(Former);

			if (peekNext(")")) {
				checkNext(")");
			}
		}

		ifStatement.setExp(Former);

		if (peekNext(")")) {
			checkNext(")");
		}
		checkNext("then");

		ifStatement.setState(parseStmts(new ArrayList<>()));

		if (peekNext("else")) {
			checkNext("else");
			ifStatement.setStateExp(parseStmts(new ArrayList<>()));
		}

		checkNext("end");
		checkNext("if");
		checkNext(";");
		stats.add(ifStatement);
	}

	private void parsePrintStatement(List<Statement> stats) throws ParseException {
		Token printToken = tkn.removeFirst();
		OutputStatement outputStatementStatement = new OutputStatement(printToken);

		if (peekNext("(") && peekTwoAhead("(")) {
			checkNext("(");
		}

		if (peekTwoAhead(")")) {
			throw new ParseException("Incompatible parentheses usage detected; please revise the technical expression", tkn.getFirst());
		}

		Expression Former = null;

		while(!peekNext(";")) {
			Former = exp2(Former);

			if (peekNext(")")) {
				checkNext(")");
			}
		}

		outputStatementStatement.setExpr(Former);

		if (peekNext(")")) {
			checkNext(")");
		}

		checkNext(";");
		stats.add(outputStatementStatement);
	}

	private void parsePrintLineStatement(List<Statement> stats) throws ParseException {
		Token printLineToken = tkn.removeFirst();
		LinePrinterStatement printLineStatement = new LinePrinterStatement(printLineToken);
		checkNext(";");
		stats.add(printLineStatement);
	}

	private void parseReturnStatement(List<Statement> stats) throws ParseException {
		Token returnToken = tkn.removeFirst();
		ResultStatement resultStatementStatement = new ResultStatement(returnToken);

		if (peekNext("(") && peekTwoAhead("(")) {
			checkNext("(");
		}

		if (!peekNext(";")) {
			Expression Former = null;

			do {
				Former = exp2(Former);

				if (peekNext(")")) {
					checkNext(")");
				}
			} while (!peekNext(";"));

			resultStatementStatement.setExp(Former);
		}

		if (peekNext(")")) {
			checkNext(")");
		}

		checkNext(";");
		stats.add(resultStatementStatement);
	}

	private void parseWhileStatement(List<Statement> stats) throws ParseException {
		Token whileToken = tkn.removeFirst();
		LogicLoopStatement logicLoopStatement = new LogicLoopStatement(whileToken);

		if (peekNext("(") && peekTwoAhead("(")) {
			checkNext("(");
		}

		Expression Former = null;

		do {
			Former = exp2(Former);

			if (peekNext(")")) {
				checkNext(")");
			}
		} while (!peekNext("do"));

		logicLoopStatement.setOperand(Former);

		checkNext("do");

		logicLoopStatement.setBodyStatements(parseStmts(new ArrayList<>()));

		checkNext("end");
		checkNext("while");
		checkNext(";");
		stats.add(logicLoopStatement);
	}

	private void parseVarDeclStatement(List<Statement> stats) throws ParseException {
		Token initializationToken = tkn.removeFirst();
		VarDeclStatement varDeclStatementStatement = new VarDeclStatement(initializationToken);

		varDeclStatementStatement.setVarName(initializationToken.getValue());

		if (peekNext(";")) {
			checkNext(";");
			stats.add(varDeclStatementStatement);
		} else {
			checkNext(":");
			checkNext("=");

			while (peekNext("(") && peekTwoAhead("(")) {
				checkNext("(");
			}

			Expression Former = null;

			while (!peekNext(";")) {
				Former = exp2(Former);

				if (peekNext(")")) {
					checkNext(")");
				}
			}

			varDeclStatementStatement.setValueExpr(Former);

			if (peekNext(")")) {
				checkNext(")");
			}

			checkNext(";");
			stats.add(varDeclStatementStatement);
		}
	}

	private void parseFunctionCallStatement(List<Statement> stats) throws ParseException {
		Token functionCallToken = tkn.removeFirst();
		InvokeFunctionStatement invokeFunctionStatementStatement = new InvokeFunctionStatement(functionCallToken);

		if (peekNext("(")) {
			checkNext("(");
		}

		List<Expression> Inputs = new ArrayList<>();

		for (; !peekNext(")") && !peekNext(";"); ) {
			if (peekNext(",")) {
				checkNext(",");
			}

			Expression exp = exp2(null);

			if (exp != null) {

				Inputs.add(exp);
			}
		}

		invokeFunctionStatementStatement.setArg(Inputs);

		invokeFunctionStatementStatement.setTag(functionCallToken.getValue());

		if (peekNext(")")) {
			checkNext(")");
		}

		checkNext(";");
		stats.add(invokeFunctionStatementStatement);
	}


	/**
	 * Parses an expression.
	 *
	 * @param lst Former expression in the context of binary operations.
	 * @return Parsed expression.
	 * @throws ParseException If there is an error in parsing.
	 */
	private Expression exp2(Expression lst) throws ParseException {
		Token tkn = this.tkn.getFirst();
		Matcher
				Designation = StructureBlueprint.matcher(tkn.getValue());
		boolean
				DoesDesignationMatch = Designation.find() && (!tkn.getValue().startsWith("" + (char) 34) && !tkn.getValue().endsWith("" + (char) 34));
		Matcher
				TokenValue = namingConvention.matcher(tkn.getValue());
		boolean
				TokenValueComparison = TokenValue.find();
		Matcher
				Comparator = namingConvention.matcher(this.tkn.get(2).getValue());

		if (peekNext("(") && this.tkn.get(1).getValue().equals("-") && Comparator.find() && this.tkn.get(3).getValue().equals(")")) {
			checkNext("(");
			this.tkn.removeFirst();
			Token Tokenl = this.tkn.removeFirst();
			Expression exp = new AnnotatedTokenValueExpression(Tokenl, "-" + Tokenl.getValue(), Type.Integer);
			checkNext(")");
			return exp;
		}

		if (TokenValueComparison || this.tkn.getFirst().getValue().equals("0")) {
			Token Tll = this.tkn.removeFirst();
			Expression exp = new AnnotatedTokenValueExpression(Tll, Tll.getValue(), Type.Integer);
			return exp;
		} else if (this.tkn.getFirst().getValue().startsWith("" + (char) 34) && this.tkn.getFirst().getValue().endsWith("" + (char) 34)) {
			Token Tokenll = this.tkn.removeFirst();
			Expression exp = new AnnotatedTokenValueExpression(Tokenll, Tokenll.getValue(), Type.String);
			return exp;
		} else if (this.tkn.getFirst().getValue().equals("true") || this.tkn.getFirst().getValue().equals("false")) {
			Token Tl = this.tkn.removeFirst();
			Expression exp = new AnnotatedTokenValueExpression(Tl, Tl.getValue(), Type.Boolean);
			return exp;
		} else if (DoesDesignationMatch && !peekTwoAhead("(") && !tkn.getValue().equals("not")) {
			Token labelToken = this.tkn.removeFirst();
			Expression label = new IdentifierExpression(labelToken, labelToken.getValue());
			return label;
		} else if (DoesDesignationMatch && peekTwoAhead("(")) {
			Token token1 = this.tkn.removeFirst();
			checkNext("(");
			List<Expression>
					Inputs = new LinkedList<>();
			do {
				if (peekNext(",")) checkNext(",");
				Inputs.add(exp2(null));
			} while (!peekNext(")"));

			checkNext(")");
			Expression handler = new DynamicOperationHandlerExpression(token1, token1.getValue(), Inputs);
			return handler;
		} else if (lst == null && (peekNext("(") || isTwoOperandsExpression())) {
			checkNext("(");
			if (peekTwoAhead(")")) {
				throw new ParseException("This expression type is not compatible and cannot be processed.", this.tkn.getFirst());
			}
			boolean monadicSymbol = isMonadicSymbol();
			Expression unaryOpExp = null;
			if (monadicSymbol) {
				Token OpunryTkn = this.tkn.removeFirst();
				unaryOpExp = new CustomUnaryOperatorExpression(OpunryTkn, OpunryTkn.getValue(), exp2(null));
				checkNext(")");
			}
			boolean BiOpExp = isTwoOperandsExpression();
			if (BiOpExp) {
				Expression expLeft = (monadicSymbol) ? unaryOpExp : exp2(null);
				Token biOpTkn = this.tkn.removeFirst();
				Expression biOpExp = new ArithmeticLogicExpression(biOpTkn, biOpTkn.getValue(), expLeft, exp2(null));
				checkNext(")");
				Expression left = biOpExp;
				if (isTwoOperandsExpression() && !peekNext(")")) {
					Token binOpToken2 = this.tkn.removeFirst();
					Expression binOpExp2 = new ArithmeticLogicExpression(binOpToken2, binOpToken2.getValue(), left, exp2(null));
					if (peekNext(")") && peekTwoAhead(")")) checkNext(")");
					return binOpExp2;
				}
				return biOpExp;
			}
			return unaryOpExp;
		} else if (lst != null && (peekNext("(") || isTwoOperandsExpression())) {
			if (peekNext("(")) checkNext("(");
			boolean ExpBOper = isTwoOperandsExpression();
			if (ExpBOper) {
				Expression Former1 = lst;
				Token binaryOperatorToken = this.tkn.removeFirst();
				if (peekNext("(") && peekTwoAhead("(")) checkNext("(");
				Expression arithmeticLogicExp = new ArithmeticLogicExpression(binaryOperatorToken, binaryOperatorToken.getValue(), Former1, exp2(null));
				checkNext(")");
				while (peekNext(")") && peekTwoAhead(")")) checkNext(")");
				Expression left = arithmeticLogicExp;
				if (isTwoOperandsExpression()) {
					Token TokenOpeb2 = this.tkn.removeFirst();
					Expression arithmeticLogicExp1 = new ArithmeticLogicExpression(TokenOpeb2, TokenOpeb2.getValue(), left, exp2(null));
					checkNext(")");
					return arithmeticLogicExp1;
				}
				return arithmeticLogicExp;
			}
			return null;
		} else {
			throw new ParseException("Unsupported expression type" + tkn.getValue() + " " + tkn.getLine(), tkn);
		}
	}
	private boolean isTwoOperandsExpression() {
		List<String>ActionSymbol = Arrays.asList("and", "or", ">", "<", "==", ">=", "<=", "+", "-", "*", "/", "%");

		Iterator<String> iterator = ActionSymbol.iterator();
		do {
			String OperationSymbol = iterator.next();
			if (peekNext(OperationSymbol) || peekTwoAhead(OperationSymbol)) {
				return true;
			}
		} while (iterator.hasNext());
		return false;
	}
	private boolean isMonadicSymbol() {
		List<String> ActionSymbol = Arrays.asList("-", "not");

		Iterator<String> iterator = ActionSymbol.iterator();
		while (iterator.hasNext()) {
			String OperationSymbol = iterator.next();
			if (peekNext(OperationSymbol)) {
				return true;
			}
		}
		return false;
	}
}
